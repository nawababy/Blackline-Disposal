using System;

[Serializable]
public sealed class WorldTrashSaveData
{
    /*
     * Eindeutige ID dieses einzelnen M�llobjekts.
     *
     * Zwei verschiedene M�lls�cke d�rfen niemals
     * dieselbe World Object ID besitzen.
     */
    public string worldObjectId =
        string.Empty;

    /*
     * ID der M�llart.
     *
     * Beispiele:
     * trash.garbage_bag
     * trash.body_bag
     */
    public string trashTypeId =
        string.Empty;

    /*
     * Name der Szene, in der das Objekt gespeichert wurde.
     */
    public string sceneName =
        string.Empty;

    /*
     * True:
     * Das M�llobjekt existiert noch.
     *
     * False:
     * Das M�llobjekt wurde verarbeitet oder entfernt.
     */
    public bool exists = true;

    public SerializableVector3 position =
        new SerializableVector3();

    public SerializableVector3 rotation =
        new SerializableVector3();
}